// подключение express и socket.io 
const app = require('express')();
const server = require('http').Server(app);
const io = require('socket.io')(server);

const path = require('path'); 

const port = 8081; 

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// пространства имен в socket.io создаются с помощью функции io.of('namespace_name') 
const namespace = io.of('/namespace'); 
// подключение к именному пространству socket.io 
namespace.on('connection', function (socket) {
    console.log('connected to namespace');
    // генерация события greet 
    namespace.emit('greet', { message: 'Hello from namespace!' });

});
server.listen(port, function () {
    console.log('app running on port ' + port);
});