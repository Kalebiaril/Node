// подключение express и socket.io 
const app = require('express')();
const server = require('http').Server(app);
const io = require('socket.io')(server);

const path = require('path'); 

const port = 8081; 
app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'index.html'));
});
io.on('connection', function (socket) {    
    // отправка данных клиенту 
    socket.emit('data', { message: 'data from server' }); 
    // подтверждение получения данных клиентом 
    socket.on('response', function (data) {
        console.log(data.message);
    });
});
server.listen(port, function () {
    console.log('app running on port ' + port); 
})