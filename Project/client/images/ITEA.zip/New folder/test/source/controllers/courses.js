import { CourseView } from '../views';
import { Router } from 'express';

const router = new Router();

router.route('/course')
    .get(async (req, res) => {
        CourseView.get_all_courses(req, res);
    });

export { router };