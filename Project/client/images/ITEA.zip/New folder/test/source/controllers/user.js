import { UserView } from '../views';
import { Router } from 'express';

const router = new Router();

router.route('/user')
    .get(async (req, res) => {
        UserView.get_all_users(req, res);
    })
    .post(async (req, res) => {
        UserView.create_user(req, res);
    });

router.route('/user/:id')
    .get(async (req, res) => {
        UserView.get_user_by_id(req, res);
    });

export default router;