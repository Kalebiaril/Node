import { register_route } from './register_routes';

export {
    register_route
}