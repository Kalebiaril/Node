import { Course } from '../models'

export async function get_all_courses(req, res) {
    let courses = null;
    try{
        console.log(`User ${req.user.name} requests all courses.`)
        courses = await Course.find({});

        res.status(200).json(courses);
    }
    catch(err){
        console.log(err);
        res.status(500).json({Error: "Something went wrong."});
    }
}