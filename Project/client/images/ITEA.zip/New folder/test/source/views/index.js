import * as UserView from './user';
import * as CourseView from './courses';

export {
    UserView,
    CourseView
}