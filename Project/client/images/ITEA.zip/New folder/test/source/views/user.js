import { User, Course } from '../models'

export async function get_all_users(req, res) {
    let users = null;
    let limit = req.query.limit ? parseInt(req.query.limit) : 10;
    let skip = req.query.skip ? parseInt(req.query.skip) : 0;
    try{
        users = await User.find({}).skip(skip).limit(limit);

        // User.find({}).then((result) => {
        //     res.status(200).json(users);
        // });
        res.status(200).json(users);
    }
    catch(err){
        console.log(err);
        res.status(500).json({Error: "Something went wrong."});
    }
}

export async function create_user(req, res) {
    let user = req.body;
    if(!user){
        res.status(400).json({Error: "User doesn't pass."});
    }
    try{
        user = new User(user);

        let err = user.validateSync();
        if(err){
            res.status(409).json({Error: "User is not valid."});
        }
        user = await user.save();

        res.status(200).json(user);
    }
    catch(err){
        console.log(err);
        res.status(500).json({Error: "User not created."});
    }
}

export async function get_user_by_id(req, res) {
    let user = null;
    let user_id = req.params.id;
    if(!user_id){
        res.status(404).json({Error: `User by user id ${user_id} not found.`});
    }
    try{
        //user = await User.find({ _id: user_id});
        user = await User.findById(user_id).populate('course_id', 'name');
        // User.create_user();
        // User.find({}).then((result) => {
        //     res.status(200).json(users);
        // });
        res.status(200).json(user);
    }
    catch(err){
        console.log(err);
        res.status(500).json({Error: "Something went wrong."});
    }
}