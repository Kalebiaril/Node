import User from './user';
import Course from './course';

export {
    User,
    Course
}