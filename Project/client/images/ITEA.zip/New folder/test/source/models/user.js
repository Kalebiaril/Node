import mongoose from 'mongoose';
const Schema = mongoose.Schema;

let UserSchema = new Schema({
    name: { type: String, required: true },
    age: { type: Number },
    course_id: { type: mongoose.SchemaTypes.ObjectId, ref: 'Course' }
});

// static method
// UserSchema.statics.create_user()

// hooks
// UserSchema.pre('save', () => {

// })

// UserSchema.post('save', () => {
    
// })

let User = mongoose.model('User', UserSchema);

export default User;
