const assert = require("assert");
const chai = require("chai");
const request = require('request');

const base_url = 'http://localhost:8082/api';


describe("/user create test", function() {
  it("should return -1 when the value is not present", function() {
      // 
      let mock_user = {
          name: "Vitaliy",
          age: 10
      }
      request.post(`${base_url}/user`, {
          json: mock_user
      },  (err, res) => {
        if(err){
            console.log(err)
            assert.fail("User not created.");
            return;
        }

        assert.equal(res.statusCode, 200);
        let body = res.body;
        assert.equal(body.name, mock_user.name);
        assert.equal(body.age, mock_user.age);

      })
  });
});